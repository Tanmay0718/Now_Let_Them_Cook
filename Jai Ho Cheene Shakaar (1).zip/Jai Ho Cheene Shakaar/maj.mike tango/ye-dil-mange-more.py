import cv2
import os
import serial
import time
from clarifai.rest import ClarifaiApp
from clarifai.rest import Image as ClImage
import numpy as np

# --- Clarifai Setup ---
CLARIFAI_API_KEY = 'YOUR_API_KEY_HERE'  # Replace with your actual API key
app = ClarifaiApp(api_key=CLARIFAI_API_KEY)
model = app.public_models.general_model

# --- Arduino Setup ---
arduino = serial.Serial('COM3', 9600)
time.sleep(2)

# --- Function to Classify Image using Clarifai ---
def classify_image_with_clarifai(frame):
    try:
        # Convert frame to a format Clarifai accepts
        _, img_encoded = cv2.imencode('.jpg', frame)  # Convert frame to JPEG
        img_bytes = img_encoded.tobytes()  # Get byte array from encoded image
        
        # Use the image bytes with Clarifai
        image = ClImage(file_obj=img_bytes)
        response = model.predict([image])

        # Check if predictions are successful
        if not response['outputs']:
            return None
        
        concepts = response['outputs'][0]['data']['concepts']
        for concept in concepts:
            name = concept['name'].lower()
            confidence = concept['value']
            if confidence < 0.85:  # Only accept predictions above 85%
                continue
            if any(word in name for word in ['plastic', 'bottle']):
                return 'plastic'
            elif any(word in name for word in ['metal', 'can']):
                return 'metal'
            elif any(word in name for word in ['organic', 'food', 'vegetable', 'paper', 'cardboard']):
                return 'organic'
        return None
    except Exception as e:
        print("Error during Clarifai prediction:", e)
        return None

# --- Background Subtraction Setup ---
def initialize_background(frame, width=200, height=200):
    background = cv2.resize(frame, (width, height))  # Resize to consistent size
    return background

def is_frame_similar_to_background(frame, background, threshold=5000):
    # Resize current frame to match the background size
    frame_resized = cv2.resize(frame, (background.shape[1], background.shape[0]))

    # Compute the absolute difference between the background and the current frame
    diff = cv2.absdiff(background, frame_resized)
    
    # Sum all pixel differences
    score = np.sum(diff)
    return score < threshold

# --- Main Webcam Loop ---
cap = cv2.VideoCapture(0)

print("System is running. Press 'q' to quit.")

# Capture background when the system starts
ret, frame = cap.read()
if ret:
    background = initialize_background(frame)

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    # Check if the frame is similar to the background (empty dustbin)
    if is_frame_similar_to_background(frame, background):
        print("No garbage detected.")
        continue  # Skip this frame and do not send to API

    # Classify the captured frame
    category = classify_image_with_clarifai(frame)

    # Show the frame
    cv2.imshow("Live Feed", frame)

    # Act based on category
    if category:
        print("Detected:", category)
        if category == "organic":
            arduino.write(b'O')
        elif category == "plastic":
            arduino.write(b'P')
        elif category == "metal":
            arduino.write(b'M')
        time.sleep(3)
    else:
        print("No clear category detected.")

    # Break condition
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# --- Cleanup ---
cap.release()
cv2.destroyAllWindows()
arduino.close()
