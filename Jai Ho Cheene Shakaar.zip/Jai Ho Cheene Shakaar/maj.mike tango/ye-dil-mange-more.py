# --- Required Libraries ---
import cv2
import os
import serial
import time
from clarifai.rest import ClarifaiApp
from clarifai.rest import Image as ClImage

# --- Clarifai Setup ---
CLARIFAI_API_KEY = 'YOUR_API_KEY_HERE'  # Replace with your actual API key
app = ClarifaiApp(api_key=CLARIFAI_API_KEY)
model = app.public_models.general_model  # You can also try 'food' or 'custom-trained' if needed

# --- Arduino Setup ---
arduino = serial.Serial('COM3', 9600)
time.sleep(2)

# --- Function to Classify Image using Clarifai ---
def classify_image_with_clarifai(image_path):
    image = ClImage(filename=image_path)
    response = model.predict([image])

    concepts = response['outputs'][0]['data']['concepts']
    for concept in concepts:
        name = concept['name'].lower()
        if any(word in name for word in ['plastic', 'bottle']):
            return 'plastic'
        elif any(word in name for word in ['metal', 'can']):
            return 'metal'
        elif any(word in name for word in ['organic', 'food','Vegetable','Paper','cardboard']):
            return 'organic'
    return None

# --- Main Webcam Loop ---
cap = cv2.VideoCapture(0)
print("System is running. Press 'q' to quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    # Save the current frame temporarily
    cv2.imwrite("current_frame.jpg", frame)

    # Classify the saved image
    category = classify_image_with_clarifai("current_frame.jpg")

    # Show the frame
    cv2.imshow("Live Feed", frame)

    # Act based on category
    if category:
        print("Detected:", category)
        if category == "organic":
            arduino.write(b'O')
        elif category == "plastic":
            arduino.write(b'P')
        elif category == "metal":
            arduino.write(b'M')
        time.sleep(3)
    else:
        print("No clear category detected.")

    # Break condition
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# --- Cleanup ---
cap.release()
cv2.destroyAllWindows()
arduino.close()
